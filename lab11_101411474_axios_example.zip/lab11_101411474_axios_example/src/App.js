import React from 'react';
import PersonList from './PersonList';

function App() {
    return (
        <div className="App">
            <PersonList />
        </div>
    );
}

export default App;
